import{l as o,a as r}from"../chunks/Chix1t7D.js";export{o as load_css,r as start};
