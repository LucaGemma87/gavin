import{_ as m}from"../chunks/0QC5lucq.js";export{m as component};
