import{a1 as e}from"../chunks/C_x2Fvxh.js";export{e as component};
